create
    definer = root@localhost procedure usp_get_older(IN minionId int)
begin
    update  minions
    set age=age+1
    where id = minionId;
end;

