//package fifth;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import java.time.Month;
//import java.time.Year;
//@Entity
//public class CreditCard extends BillingDetail {
//    @Column(name = "card_type")
//    private String cardType;
//    @Column(name="exploration_month")
//    private Month explorationMonth;
//    @Column(name = "exploration_year")
//    private Year explorationYear;
//
//    public CreditCard() {
//    }
//
//    public String getCardType() {
//        return cardType;
//    }
//
//    public void setCardType(String cardType) {
//        this.cardType = cardType;
//    }
//
//    public Month getExplorationMonth() {
//        return explorationMonth;
//    }
//
//    public void setExplorationMonth(Month explorationMonth) {
//        this.explorationMonth = explorationMonth;
//    }
//
//    public Year getExplorationYear() {
//        return explorationYear;
//    }
//
//    public void setExplorationYear(Year explorationYear) {
//        this.explorationYear = explorationYear;
//    }
//}
