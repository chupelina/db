

import entities.*;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Engine implements Runnable {
    private final EntityManager entityManager;
    private final Scanner scan;

    public Engine(EntityManager entityManager) {
        this.entityManager = entityManager;
        this.scan = new Scanner(System.in);
    }


    @Override
    public void run() {

    }

    //2. Change casing
    public void changeCasing() {
        List<Town> towns = entityManager.createQuery
                ("Select t from Town t where length(t.name)<=5 ", Town.class)
                .getResultList();
        entityManager.getTransaction().begin();
        towns.forEach(entityManager::detach);
        for (Town town : towns) {
            town.setName(town.getName().toLowerCase());
        }
        towns.forEach(entityManager::merge);
        entityManager.flush();
        entityManager.getTransaction().commit();
    }

    //3. Contains Employee
    public void containsEmployee() {
        String name = scan.nextLine();
        List<Employee> employees = entityManager.createQuery
                ("select e from Employee as e where  " +
                        "concat(e.firstName, ' ', e.lastName) =:name ", Employee.class)
                .setParameter("name", name).getResultList();
        if (employees.isEmpty()) {
            System.out.println("No");
        } else {
            System.out.println("Yes");
        }
    }

    //4. Employees with Salary Over 50 000
    public void employeeWithSalaryOver() {
        entityManager.createQuery("select e from Employee as e " +
                "where  e.salary>50000", Employee.class).getResultStream()
                .map(Employee::getFirstName)
                .forEach(System.out::println);
    }

    //5. Employees from Department
    public void employeesFromDepartment() {
        List<Employee> employees = entityManager.createQuery("select e from Employee as e " +
                "where e.department.name=:name " +
                "order by e.salary , e.id", Employee.class)
                .setParameter("name", "Research and Development")
                .getResultList();

        employees.forEach(e -> System.out.printf("%-11s %-19s from Research and Development - $%.2f%n",
                e.getFirstName(), e.getLastName(), e.getSalary()));
    }

    //6. Adding a New Address and Updating Employee
    public void addingNewAddress() {
        String name = scan.nextLine();
        Address address = createNewAddress("Vitoshka 15");
        Employee employees = entityManager.createQuery("select e from Employee e " +
                " where e.lastName=:name", Employee.class)
                .setParameter("name", name).getSingleResult();
        entityManager.getTransaction().begin();
        employees.setAddress(address);
        entityManager.getTransaction().commit();
    }

    //6.1
    private Address createNewAddress(String s) {
        Address address = new Address();
        address.setText(s);
        entityManager.getTransaction().begin();
        entityManager.persist(address);
        entityManager.getTransaction().commit();
        return address;
    }

    //7. Addresses with Employee Count
    public void addressCount() {
        List<Address> addresses = entityManager.createQuery("select a from  Address  as a " +
                "order by a.employees.size desc ", Address.class)
                .setMaxResults(10).getResultList();
        addresses.forEach(address -> System.out.printf("%-23s, %-14s - %d employees%n",
                address.getText(), address.getTown().getName(), address.getEmployees().size()));
    }

    //8. Get Employee with Project
    public void getEmployee() {
        int id = Integer.parseInt(scan.nextLine());
        Employee employee = entityManager.find(Employee.class, id);
        System.out.printf("%s %s - %s%n", employee.getFirstName(), employee.getLastName()
                , employee.getDepartment().getName());
        employee.getProjects().stream().sorted(Comparator.comparing(Project::getName))
                .forEach(p -> System.out.println("\t" + p.getName()));
    }

    //9. Find Latest 10 Projects
    public void findLatestProjects() {
        List<Project> projects = entityManager.createQuery("SELECT p from  Project as p order by p.startDate desc",
                Project.class).setMaxResults(10).getResultList();
        projects.stream().sorted(Comparator.comparing(Project::getName)).forEach(p -> {
                    System.out.println("Project name: " + p.getName());
                    System.out.println("\tProject Description: " + p.getDescription());
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.s");
                    System.out.println("\tProject Start Date: " + p.getStartDate().format(formatter));
                    System.out.println("\tProject End Date: " + ((p.getEndDate() == null) ? null :
                            p.getEndDate().format(formatter)));
                }
        );
    }

    //10. Increase Salaries
    public void increaseSalaries() {
        List<Employee> employees = entityManager.createQuery("Select e from Employee as e " +
                        "where e.department.name in ('Engineering', 'Tool Design', 'Marketing', 'Information Services')"
                , Employee.class).getResultList();
        entityManager.getTransaction().begin();
        BigDecimal b = new BigDecimal(1.12);
        for (Employee employee : employees) {
            entityManager.find(Employee.class, employee.getId()).setSalary(employee.getSalary().multiply(b));
        }
        entityManager.getTransaction().commit();
        for (Employee employee : employees) {
            System.out.printf("%-15s %-18s ($%.2f)%n", employee.getFirstName(),
                    employee.getLastName(), employee.getSalary());
        }
    }

    //11. ind Employees by First Name
    public void findByFirstName() {
        String input = scan.nextLine();
        String regex = input + "%";
        List<Employee> employees = entityManager.createQuery("select e from Employee  as e " +
                "where e.firstName like :name", Employee.class).setParameter("name", regex)
                .getResultList();
        for (Employee employee : employees) {
            System.out.printf("%-10s %-18s - %-25s ($%.2f)%n", employee.getFirstName(),
                    employee.getLastName(), employee.getDepartment().getName(), employee.getSalary());
        }
    }

    //12. Employees Maximum Salaries
    public void maximumSalaries() {
        List<Employee> employees = new ArrayList<>();

        for (int i = 1; i < 17; i++) {
            List<Employee> inDepartment = entityManager.createQuery("select e from Employee as e " +
                    "where e.department.id =:id " +
                    "order by  e.salary desc ", Employee.class).setParameter("id", i)
                    .getResultList();
            Employee current = inDepartment.get(0);
            if (current.getSalary().compareTo(BigDecimal.valueOf(30000)) < 0 ||
                    current.getSalary().compareTo(BigDecimal.valueOf(70000)) > 0) {
                employees.add(current);
            }
        }
        for (Employee employee : employees) {
            System.out.printf("%-30s  %-15.2f %n",employee.getDepartment().getName() , employee.getSalary());
        }
    }

    //13. Remove Towns
    public void deleteTowns(){
        String town = scan.nextLine();
        Town town1 = entityManager.createQuery("select t from Town as t  where t.name " +
                "=:name ",Town.class).setParameter("name", town).getSingleResult();
        List<Employee> livedIn = entityManager.createQuery("select e from Employee as e " +
                "where e.address.town.id=:id", Employee.class).setParameter("id", town1.getId())
                .getResultList();
        entityManager.getTransaction().begin();
        for (Employee employee : livedIn) {
            employee.setAddress(null);
        }
        entityManager.getTransaction().commit();
        entityManager.getTransaction().begin();
        int n = entityManager.createQuery("delete from Address as a where a.town.id=:id")
                .setParameter("id", town1.getId()).executeUpdate();
        entityManager.createQuery("delete  from Town as t where t.id=:id")
                .setParameter("id", town1.getId()).executeUpdate();
        entityManager.getTransaction().commit();

        System.out.printf("%d address in %s deleted%n", n , town1.getName());

    }
}
