
import entities.Town;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import java.sql.SQLOutput;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("soft_uni");
        EntityManager em = factory.createEntityManager();
        Engine engine = new Engine(em);
        engine.run();
        Scanner scan = new Scanner(System.in);
        System.out.println("Lets play a game, if you want to quit press 1.");
        int input = Integer.parseInt(scan.nextLine());
        while (input != 1) {
            switch (input) {
                case 2:
                    System.out.println("Just check the data :)");
                    engine.changeCasing();
                    break;
                case 3:
                    System.out.println("Type the name of the employee that you want to check:");
                    engine.containsEmployee();
                    break;
                case 4:
                    System.out.println("And the richest employees are:");
                    engine.employeeWithSalaryOver();
                    break;
                case 5:
                    System.out.println("Those who work in the Research and Development department are:");
                    engine.employeesFromDepartment();
                    break;
                case 6:
                    System.out.println("Type the last name of the person whose address you want to change:");
                    engine.addingNewAddress();
                    break;
                case 7:
                    System.out.println("Addresses with the most people in them are: ");
                    engine.addressCount();
                    break;
                case 8:
                    System.out.println("Type the id of the employee that you want to check");
                    engine.getEmployee();
                    break;
                case 9:
                    System.out.println("And the 10 latest projects are: ");
                    engine.findLatestProjects();
                    break;
                case 10:
                    System.out.println("Increased salaries are: ");
                    engine.increaseSalaries();
                    break;
                case 11:
                    System.out.println("Type some letters and I will give you all employees whose " +
                            "first name starts with them:");
                    engine.findByFirstName();
                    break;
                case 12:
                    System.out.println("Here are the highest salaries from each department");
                    engine.maximumSalaries();
                    break;
                case 13:
                    System.out.println("You want to delete a town? Type its name:");
                    engine.deleteTowns();
                    break;
            }
            System.out.println("If you want to quit press 1");
            input = Integer.parseInt(scan.nextLine());
        }
        System.out.println("Thanks for your time :)");
    }
}
